import React, { useState, useMemo } from 'react';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { CartProvider } from './hooks/useCart';
import Header from './Components/Layout/Header';
import Login from './Components/Auth/Login';
import Register from './Components/Auth/Register';
import Hero from './Components/Home/hero';
import CategoryGrid from './Components/Home/CategoryGrid';
import DishGrid from './Components/Food/DishGrid';
import LateNightSection from './Components/Restaurants/LateNightSection';
import { mockDishes } from './data/mockData';
import './App.css';
import UserDashboard from './pages/UserDashboard';
import CartDrawer from './Components/Cart/CartDrawer';

function AppContent() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);

  const { user } = useAuth();

  // Memoized filtered dishes
  const filteredDishes = useMemo(() => {
    let filtered = mockDishes;
    if (searchTerm) {
      filtered = filtered.filter(dish =>
        dish.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dish.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dish.restaurant.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    if (selectedCategory) {
      filtered = filtered.filter(dish =>
        dish.category.toLowerCase() === selectedCategory.toLowerCase()
      );
    }
    return filtered;
  }, [searchTerm, selectedCategory]);

  const popularDishes = mockDishes.filter(dish => dish.isPopular);

  // Dummy handleLogin for modal close
  const handleLogin = () => {
    setShowLogin(false);
    setShowRegister(false);
  };

  return (
    <>
      <Header 
        onLoginClick={() => setShowLogin(true)}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
      />
      {user ? (
        <>
          <UserDashboard />
          <CartDrawer />
        </>
      ) : (
        <>
          {showLogin && (
            <Login 
              onClose={() => setShowLogin(false)} 
              onSwitchToRegister={() => { setShowLogin(false); setShowRegister(true); }}
              onLogin={handleLogin}
            />
          )}
          {showRegister && (
            <Register 
              onClose={() => setShowRegister(false)} 
              onSwitchToLogin={() => { setShowRegister(false); setShowLogin(true); }}
              onRegister={handleLogin}
            />
          )}
          <main>
            {/* Hero Section */}
            <Hero />
            {/* Category Grid */}
            <CategoryGrid 
              onCategorySelect={setSelectedCategory}
              selectedCategory={selectedCategory}
            />
            {/* Popular Dishes */}
            {!searchTerm && !selectedCategory && (
              <DishGrid 
                dishes={popularDishes} 
                title="Popular Dishes"
              />
            )}
            {/* Filtered Results */}
            {(searchTerm || selectedCategory) && (
              <DishGrid 
                dishes={filteredDishes}
                title={
                  searchTerm 
                    ? `Search results for "${searchTerm}"` 
                    : `${selectedCategory?.charAt(0).toUpperCase()}${selectedCategory?.slice(1)} Dishes`
                }
              />
            )}
            {/* All Dishes (when no filter is applied) */}
            {!searchTerm && !selectedCategory && (
              <DishGrid 
                dishes={mockDishes}
                title="All Dishes"
              />
            )}
            {/* Late Night Section */}
            <LateNightSection />
          </main>
          {/* Footer */}
          <footer className="footer">
            <div className="footer-container">
              <div className="footer-grid">
                <div className="footer-section">
                  <h3>SB Foods</h3>
                  <p>Your favorite food delivered fresh, anytime, anywhere.</p>
                </div>
                <div className="footer-section">
                  <h4>Quick Links</h4>
                  <ul className="footer-links">
                    <li><a href="#about">About Us</a></li>
                    <li><a href="#restaurants">Restaurants</a></li>
                    <li><a href="#contact">Contact</a></li>
                    <li><a href="#careers">Careers</a></li>
                  </ul>
                </div>
                <div className="footer-section">
                  <h4>Support</h4>
                  <ul className="footer-links">
                    <li><a href="#help">Help Center</a></li>
                    <li><a href="#track">Track Order</a></li>
                    <li><a href="#faq">FAQs</a></li>
                    <li><a href="#terms">Terms & Conditions</a></li>
                  </ul>
                </div>
                <div className="footer-section">
                  <h4>Contact Info</h4>
                  <div className="footer-contact">
                    <p>📞 (555) 123-4567</p>
                    <p>📧 support@sbfoods.com</p>
                    <p>📍 123 Food Street, City</p>
                  </div>
                </div>
              </div>
              <div className="footer-bottom">
                <p>&copy; 2025 SB Foods. All rights reserved. Built with ❤️ for food lovers.</p>
              </div>
            </div>
          </footer>
        </>
      )}
    </>
  );
// ...existing code...
}


function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <AppContent />
      </CartProvider>
    </AuthProvider>
  );
}

export default App;