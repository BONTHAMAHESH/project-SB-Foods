import React, { useEffect, useState } from 'react';
import {
  fetchAllUsers,
  fetchAllOrders,
  fetchAllProducts
} from '../services/api';

function AdminDashboard() {
  const [users, setUsers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [userRes, orderRes, productRes] = await Promise.all([
          fetchAllUsers(),
          fetchAllOrders(),
          fetchAllProducts()
        ]);
        setUsers(userRes.data);
        setOrders(orderRes.data);
        setProducts(productRes.data);
      } catch (err) {
        console.error('Failed to fetch admin data:', err);
      }
    };

    loadData();
  }, []);

  return (
    <div>
      <h2>Admin Dashboard</h2>

      <section>
        <h3>Users ({users.length})</h3>
        {users.map(user => (
          <div key={user._id}>
            <p>{user.name} — {user.email}</p>
          </div>
        ))}
      </section>

      <section>
        <h3>Orders ({orders.length})</h3>
        {orders.map(order => (
          <div key={order._id}>
            <p>ID: {order._id} | Total: ₹{order.total}</p>
          </div>
        ))}
      </section>

      <section>
        <h3>Products ({products.length})</h3>
        {products.map(product => (
          <div key={product._id}>
            <p>{product.name} — ₹{product.price}</p>
          </div>
        ))}
      </section>
    </div>
  );
}

export default AdminDashboard;
