import React, { useEffect, useState } from 'react';
import {
  fetchMyRestaurant,
  updateRestaurantMenu
} from '../services/api';

function RestaurantDashboard() {
  const [restaurant, setRestaurant] = useState(null);
  const [newItem, setNewItem] = useState({ name: '', price: '' });

  const loadRestaurant = async () => {
    try {
      const res = await fetchMyRestaurant();
      setRestaurant(res.data);
    } catch (err) {
      console.error('Failed to load restaurant:', err);
    }
  };

  useEffect(() => {
    loadRestaurant();
  }, []);

  const handleAddItem = async () => {
    if (!newItem.name || !newItem.price) {
      alert('Please provide both name and price');
      return;
    }

    try {
      const updatedMenu = [...restaurant.menu, newItem];
      await updateRestaurantMenu(updatedMenu);
      alert('Menu updated!');
      setNewItem({ name: '', price: '' });
      loadRestaurant();
    } catch (err) {
      console.error('Failed to update menu:', err);
    }
  };

  if (!restaurant) return <p>Loading...</p>;

  return (
    <div>
      <h2>Welcome, {restaurant.name}</h2>

      <section>
        <h3>Menu</h3>
        {restaurant.menu.length === 0 ? (
          <p>No items in the menu.</p>
        ) : (
          restaurant.menu.map((item, idx) => (
            <div key={idx}>
              <p>{item.name} — ₹{item.price}</p>
            </div>
          ))
        )}
      </section>

      <section>
        <h4>Add New Menu Item</h4>
        <input
          type="text"
          placeholder="Item Name"
          value={newItem.name}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
        />
        <input
          type="number"
          placeholder="Price"
          value={newItem.price}
          onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
        />
        <button onClick={handleAddItem}>Add Item</button>
      </section>
    </div>
  );
}

export default RestaurantDashboard;
