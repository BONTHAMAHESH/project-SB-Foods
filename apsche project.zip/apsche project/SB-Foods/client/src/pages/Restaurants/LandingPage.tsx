import React from 'react';
import { Link } from 'react-router-dom';
import FoodCategoryCard from '../Components/FoodCategoryCard';
import RestaurantCard from '../components/RestaurantCard';

const LandingPage = () => {
  const foodCategories = [
    {
      id: 1,
      name: 'Breakfast',
      image: 'https://images.pexels.com/photos/70497/pexels-photo-70497.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 2,
      name: 'Biriyani',
      image: 'https://images.pexels.com/photos/5560763/pexels-photo-5560763.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 3,
      name: 'Pizza',
      image: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 4,
      name: 'Noodles',
      image: 'https://images.pexels.com/photos/1907228/pexels-photo-1907228.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 5,
      name: 'Burger',
      image: 'https://images.pexels.com/photos/1556698/pexels-photo-1556698.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  const popularRestaurants = [
    {
      id: 1,
      name: 'Andhra Spice',
      location: 'Madhapur, Hyderabad',
      image: 'https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      id: 2,
      name: 'Mc donalds',
      location: 'Manikonda, Hyderabad',
      image: 'https://images.pexels.com/photos/1552106/pexels-photo-1552106.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Food Categories */}
      <div className="mb-12">
        <div className="flex justify-center space-x-8 mb-8">
          {foodCategories.map((category) => (
            <FoodCategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>

      {/* Popular Restaurants */}
      <div>
        <h2 className="text-2xl font-bold text-orange-500 mb-6">Popular Restaurants</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {popularRestaurants.map((restaurant) => (
            <RestaurantCard key={restaurant.id} restaurant={restaurant} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default LandingPage;