import React, { useEffect, useState } from 'react';
import { getCart, removeFromCart } from '../services/api';

function Cart() {
  const [cart, setCart] = useState([]);

  const loadCart = async () => {
    try {
      const res = await getCart();
      setCart(res.data);
    } catch (err) {
      console.error('Failed to load cart:', err);
    }
  };

  const handleRemove = async (id) => {
    try {
      await removeFromCart(id);
      loadCart(); // Reload after removal
    } catch (err) {
      alert('Failed to remove item.');
    }
  };

  useEffect(() => {
    loadCart();
  }, []);

  return (
    <div>
      <h2>Your Cart</h2>
      {cart.length === 0 ? (
        <p>No items in cart.</p>
      ) : (
        cart.map((item) => (
          <div key={item._id} style={{ border: '1px solid #ccc', padding: '1rem', marginBottom: '1rem' }}>
            <h4>{item.name}</h4>
            <p>Price: ₹{item.price}</p>
            <button onClick={() => handleRemove(item._id)}>Remove</button>
          </div>
        ))
      )}
    </div>
  );
}

export default Cart;
