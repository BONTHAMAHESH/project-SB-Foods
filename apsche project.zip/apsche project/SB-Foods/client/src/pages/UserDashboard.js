import React from 'react';
import UserSidebar from '../Components/UserSidebar';
import { useAuth } from '../hooks/useAuth';

const mockOrderCount = 7; // Replace with real order count if available

const UserDashboard = () => {
  const { user, logout } = useAuth();

  if (!user) return null;

  return (
    <div style={{ display: 'flex', gap: '2rem', padding: '2rem' }}>
      <UserSidebar user={user} orderCount={mockOrderCount} onLogout={logout} />
      <div style={{ flex: 1 }}>
        {/* Orders and other dashboard content go here */}
        <h2 style={{ fontSize: '2rem', fontWeight: 700, marginBottom: '2rem' }}>Orders</h2>
        {/* Example order cards can be added here */}
      </div>
    </div>
  );
};

export default UserDashboard;
