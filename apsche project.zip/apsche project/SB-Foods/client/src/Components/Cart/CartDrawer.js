import React, { useState } from 'react';
import { X, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useCart } from '../../hooks/useCart';
import { useAuth } from '../../hooks/useAuth';
import CheckoutModal from './CheckoutModal';

const CartDrawer = ({ isOpen, onClose }) => {
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const { items, updateQuantity, removeFromCart, getTotalPrice } = useCart();
  const { user } = useAuth();

  if (!isOpen) return null;

  const totalPrice = getTotalPrice();
  const deliveryFee = 2.99;
  const finalTotal = totalPrice + deliveryFee;

  const handleCheckout = () => {
    if (!user) {
      alert('Please sign in to place an order');
      return;
    }
    setIsCheckoutOpen(true);
  };

  return (
    <>
      <div className="cart-drawer-backdrop">
        <div className="cart-drawer">
          <div className="cart-drawer-header">
            <span className="cart-drawer-title">Your Cart</span>
            <button
              onClick={onClose}
              className="cart-drawer-close"
              aria-label="Close cart"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          <div className="cart-items-list">
            {items.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-400" style={{ minHeight: '200px' }}>
                <ShoppingBag className="h-16 w-16 mb-4" />
                <p className="text-lg font-medium">Your cart is empty</p>
                <p className="text-sm text-center">Add some delicious items to get started!</p>
              </div>
            ) : (
              items.map((item) => (
                <div key={item.dish.id} className="cart-item">
                  <img
                    src={item.dish.image || '/default-food.png'}
                    alt={item.dish.name || 'Food item'}
                    className="cart-item-img"
                  />
                  <div className="cart-item-info">
                    <span className="cart-item-title">{item.dish.name || 'Item'}</span>
                    <span className="cart-item-price">
                      ₹ {item.dish.price ? item.dish.price : '0'}
                    </span>
                    <span className="cart-item-restaurant">{item.dish.restaurant || ''}</span>
                  </div>
                  <div className="cart-item-controls">
                    <button
                      onClick={() => updateQuantity(item.dish.id, Math.max(1, item.quantity - 1))}
                      className="cart-item-qty-btn"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="cart-item-qty">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.dish.id, item.quantity + 1)}
                      className="cart-item-qty-btn"
                      aria-label="Increase quantity"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => removeFromCart(item.dish.id)}
                      className="cart-item-remove"
                      aria-label="Remove item"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Cart Summary */}
          {items.length > 0 && (
            <div className="cart-drawer-summary">
              <div className="cart-summary-row">
                <span>Subtotal</span>
                <span>₹ {totalPrice.toFixed(2)}</span>
              </div>
              <div className="cart-summary-row">
                <span>Delivery Fee</span>
                <span>₹ {deliveryFee.toFixed(2)}</span>
              </div>
              <div className="cart-summary-row total">
                <span>Total</span>
                <span>₹ {finalTotal.toFixed(2)}</span>
              </div>
              <button
                onClick={handleCheckout}
                className="cart-checkout-btn"
              >
                Proceed to Checkout
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        onOrderComplete={() => {
          setIsCheckoutOpen(false);
          onClose();
        }}
      />
    </>
  );
};

export default CartDrawer;