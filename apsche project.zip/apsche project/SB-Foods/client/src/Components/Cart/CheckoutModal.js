import React, { useState } from 'react';
import { X, MapPin, CreditCard, Clock } from 'lucide-react';
import { useCart } from '../../hooks/useCart';
import { useAuth } from '../../hooks/useAuth';

const CheckoutModal = ({ isOpen, onClose, onOrderComplete }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const { items, getTotalPrice, clearCart } = useCart();
  const { user } = useAuth();

  if (!isOpen) return null;

  const totalPrice = getTotalPrice();
  const deliveryFee = 2.99;
  const finalTotal = totalPrice + deliveryFee;

  const handlePlaceOrder = async () => {
    setIsProcessing(true);
    
    // Simulate order processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setOrderPlaced(true);
    clearCart();
    
    // Auto close after showing success
    setTimeout(() => {
      onOrderComplete();
      setOrderPlaced(false);
      setIsProcessing(false);
    }, 3000);
  };

  if (orderPlaced) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg max-w-md w-full p-6 text-center">
          <div className="mb-4">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
              <Clock className="h-6 w-6 text-green-600" />
            </div>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Order Placed Successfully!</h3>
          <p className="text-gray-600 mb-4">
            Your order has been confirmed. Estimated delivery time: 25-40 minutes.
          </p>
          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-sm text-gray-600">Order ID: #SB{Date.now().toString().slice(-6)}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Complete Your Order</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Order Details */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Order Summary</h3>
              <div className="space-y-3 mb-6">
                {items.map((item) => (
                  <div key={item.dish.id} className="flex justify-between">
                    <div>
                      <p className="font-medium">{item.dish.name}</p>
                      <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                    </div>
                    <p className="font-medium">${(item.dish.price * item.quantity).toFixed(2)}</p>
                  </div>
                ))}
              </div>
              
              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span>${deliveryFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-semibold text-lg">
                  <span>Total</span>
                  <span>${finalTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Delivery & Payment */}
            <div className="space-y-6">
              {/* Delivery Address */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-3 flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  Delivery Address
                </h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  {user?.addresses.length ? (
                    <div>
                      <p className="font-medium">{user.addresses[0].label}</p>
                      <p className="text-gray-600">
                        {user.addresses[0].street}<br />
                        {user.addresses[0].city}, {user.addresses[0].state} {user.addresses[0].zipCode}
                      </p>
                    </div>
                  ) : (
                    <p className="text-gray-600">123 College Ave, University City, CA 90210</p>
                  )}
                </div>
              </div>

              {/* Payment Method */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-3 flex items-center">
                  <CreditCard className="h-5 w-5 mr-2" />
                  Payment Method
                </h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-gray-600">•••• •••• •••• 1234</p>
                  <p className="text-sm text-gray-500">Visa ending in 1234</p>
                </div>
              </div>

              {/* Estimated Delivery Time */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-3 flex items-center">
                  <Clock className="h-5 w-5 mr-2" />
                  Estimated Delivery
                </h3>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="font-medium text-green-600">25-40 minutes</p>
                  <p className="text-sm text-gray-600">Perfect for late-night studying!</p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t">
            <button
              onClick={handlePlaceOrder}
              disabled={isProcessing}
              className="w-full bg-orange-600 text-white py-3 px-4 rounded-lg hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
            >
              {isProcessing ? 'Processing Order...' : `Place Order - $${finalTotal.toFixed(2)}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutModal;