import React from 'react';
import { Star, Clock, MapPin } from 'lucide-react';
const RestaurantCard = ({ restaurant }) => {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-105">
      <div className="relative">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
            restaurant.isOpen 
              ? 'bg-green-500 text-white' 
              : 'bg-red-500 text-white'
          }`}>
            {restaurant.isOpen ? 'Open' : 'Closed'}
          </span>
        </div>
        {restaurant.isOpen && (
          <div className="absolute top-4 right-4 bg-black bg-opacity-70 text-white px-2 py-1 rounded text-sm">
            Until {restaurant.openUntil}
          </div>
        )}
      </div>
      
      <div className="p-6">
        <h3 className="font-bold text-lg text-gray-900 mb-2">{restaurant.name}</h3>
        
        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
          <div className="flex items-center space-x-1">
            <Star className="h-4 w-4 fill-current text-yellow-400" />
            <span>{restaurant.rating}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Clock className="h-4 w-4" />
            <span>{restaurant.deliveryTime}</span>
          </div>
          <div className="flex items-center space-x-1">
            <MapPin className="h-4 w-4" />
            <span>${restaurant.deliveryFee.toFixed(2)} delivery</span>
          </div>
        </div>
        
        <div className="mb-4">
          <div className="flex flex-wrap gap-1">
            {restaurant.cuisine.slice(0, 3).map((cuisine, index) => (
              <span 
                key={index}
                className="inline-block bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs"
              >
                {cuisine}
              </span>
            ))}
          </div>
        </div>
        
        <div className="text-sm text-gray-600">
          Minimum order: ${restaurant.minimumOrder.toFixed(2)}
        </div>
      </div>
    </div>
  );
};

export default RestaurantCard;