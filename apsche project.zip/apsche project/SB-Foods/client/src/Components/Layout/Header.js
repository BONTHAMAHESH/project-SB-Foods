import React from 'react';
import { Search, ShoppingCart, LogIn } from 'lucide-react';
import { useCart } from '../../hooks/useCart';
import { useAuth } from '../../hooks/useAuth';

const Header = ({ onSearchChange, searchTerm, onLoginClick }) => {
  const { totalItems } = useCart();
  const { user, logout } = useAuth();

  return (
    <header className="header">
      <div className="header-container">
        <a href="/" className="logo">
          SB Foods
        </a>
        
        <div className="search-container">
          <Search className="search-icon" size={20} />
          <input
            type="text"
            placeholder="Search for dishes, restaurants..."
            className="search-input"
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
        
        <div className="nav-actions">
          {user ? (
            <div className="flex items-center gap-4">
              <span className="text-gray-700">Hello, {user.name}</span>
              <button onClick={logout} className="nav-button">
                Logout
              </button>
            </div>
          ) : (
            <button className="nav-button" onClick={onLoginClick}>
              <LogIn size={16} className="mr-1" />
              Login
            </button>
          )}
          
          <button className="cart-button">
            <ShoppingCart size={20} />
            {totalItems > 0 && (
              <span className="cart-count">{totalItems}</span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;