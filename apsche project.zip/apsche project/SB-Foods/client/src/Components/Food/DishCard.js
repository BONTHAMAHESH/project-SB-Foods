import React from 'react';
import { Star, Clock, Plus } from 'lucide-react';
import { useCart } from '../../hooks/useCart';

const DishCard = ({ dish }) => {
  const { addToCart } = useCart();

  const handleAddToCart = (e) => {
    e.stopPropagation();
    addToCart(dish);
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-105 group">
      <div className="relative">
        <img
          src={dish.image}
          alt={dish.name}
          className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
        />
        <div className="absolute top-4 left-4 flex space-x-2">
          {dish.isPopular && (
            <span className="bg-red-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
              Popular
            </span>
          )}
          {dish.isVegetarian && (
            <span className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
              Vegetarian
            </span>
          )}
          {dish.isSpicy && (
            <span className="bg-orange-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
              Spicy 🌶️
            </span>
          )}
        </div>
        <button
          onClick={handleAddToCart}
          className="absolute bottom-4 right-4 bg-orange-600 text-white p-2 rounded-full hover:bg-orange-700 transition-colors shadow-lg opacity-0 group-hover:opacity-100"
        >
          <Plus className="h-5 w-5" />
        </button>
      </div>
      
      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-lg text-gray-900 line-clamp-1">{dish.name}</h3>
          <span className="text-xl font-bold text-orange-600">${dish.price.toFixed(2)}</span>
        </div>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{dish.description}</p>
        
        <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
          <div className="flex items-center space-x-1">
            <Star className="h-4 w-4 fill-current text-yellow-400" />
            <span>{dish.rating}</span>
            <span>({dish.reviewCount})</span>
          </div>
          <div className="flex items-center space-x-1">
            <Clock className="h-4 w-4" />
            <span>{dish.cookTime}</span>
          </div>
        </div>
        
        <div className="border-t pt-4">
          <p className="text-sm font-medium text-gray-700 mb-1">{dish.restaurant}</p>
          <p className="text-xs text-gray-500">
            Ingredients: {dish.ingredients.slice(0, 3).join(', ')}
            {dish.ingredients.length > 3 && '...'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default DishCard;