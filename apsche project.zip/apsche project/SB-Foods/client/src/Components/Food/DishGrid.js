import React from 'react';
import { Star, Plus } from 'lucide-react';
// ...existing code...
import { useCart } from '../../hooks/useCart';

const DishGrid = ({ dishes, title }) => {
  const { addToCart } = useCart();

  const handleAddToCart = (dish) => {
    addToCart(dish);
  };

  if (dishes.length === 0) {
    return (
      <section className="dish-section">
        <div className="dish-container">
          <h2 className="dish-title">{title}</h2>
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No dishes found matching your criteria.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="dish-section">
      <div className="dish-container">
        <h2 className="dish-title">{title}</h2>
        <div className="dish-grid">
          {dishes.map((dish) => (
            <div key={dish.id} className="dish-card">
              {dish.isPopular && (
                <div className="popular-badge">Popular</div>
              )}
              <div 
                className="dish-image"
                style={{
                  backgroundImage: `url(${dish.image})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center'
                }}
              />
              <div className="dish-info">
                <h3 className="dish-name">{dish.name}</h3>
                <p className="dish-description">{dish.description}</p>
                <p className="dish-restaurant">📍 {dish.restaurant}</p>
                <div className="dish-footer">
                  <div>
                    <div className="dish-price">₹{dish.price}</div>
                    <div className="dish-rating">
                      <Star className="star" size={16} fill="currentColor" />
                      <span>{dish.rating}</span>
                      <span className="text-gray-500 ml-2">{dish.preparationTime}</span>
                    </div>
                  </div>
                  <button 
                    className="add-to-cart"
                    onClick={() => handleAddToCart(dish)}
                  >
                    <Plus size={16} className="mr-1" />
                    Add
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DishGrid;