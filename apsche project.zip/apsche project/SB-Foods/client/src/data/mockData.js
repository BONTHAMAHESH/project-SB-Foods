// Dish object shape for reference:
// {
//   id: string,
//   name: string,
//   description: string,
//   price: number,
//   image: string,
//   restaurant: string,
//   category: string,
//   rating: number,
//   isPopular: boolean,
//   preparationTime: string
// }

export const mockDishes = [
  {
    id: '1',
    name: 'Mc Maharaj',
    description: 'Big size burger with chicken, cheese, lettuce and special sauce',
    price: 175.299,
    image: 'https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg?auto=compress&cs=tinysrgb&w=400',
    restaurant: 'Mc donalds',
    category: 'burger',
    rating: 4.5,
    isPopular: true,
    preparationTime: '15-20 mins'
  },
  {
    id: '2',
    name: 'French Fries',
    description: 'Long French fries made from fresh potatoes, crispy and golden',
    price: 134.149,
    image: 'https://images.pexels.com/photos/1583884/pexels-photo-1583884.jpeg?auto=compress&cs=tinysrgb&w=400',
    restaurant: 'Mc donalds',
    category: 'sides',
    rating: 4.2,
    isPopular: true,
    preparationTime: '5-10 mins'
  },
  {
    id: '3',
    name: 'Cold Coffee',
    description: 'Tender coffee made from premium beans with ice and cream',
    price: 201.249,
    image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400',
    restaurant: 'Mc donalds',
    category: 'beverages',
    rating: 4.3,
    isPopular: false,
    preparationTime: '5 mins'
  },
  {
    id: '4',
    name: 'Chicken Pizza',
    description: 'Crispy pizza with tasty chicken, cheese and fresh vegetables',
    price: 314.349,
    image: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=400',
    restaurant: 'Paradise Grand',
    category: 'pizza',
    rating: 4.7,
    isPopular: true,
    preparationTime: '20-25 mins'
  },
  {
    id: '5',
    name: 'Chicken Biryani',
    description: 'Aromatic basmati rice with tender chicken and traditional spices',
    price: 299.99,
    image: 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg?auto=compress&cs=tinysrgb&w=400',
    restaurant: 'Andhra Spice',
    category: 'biryani',
    rating: 4.8,
    isPopular: true,
    preparationTime: '25-30 mins'
  },
  {
    id: '6',
    name: 'Masala Dosa',
    description: 'Crispy South Indian crepe with spiced potato filling',
    price: 149.99,
    image: 'https://images.pexels.com/photos/5560763/pexels-photo-5560763.jpeg?auto=compress&cs=tinysrgb&w=400',
    restaurant: 'Andhra Spice',
    category: 'breakfast',
    rating: 4.4,
    isPopular: false,
    preparationTime: '15-20 mins'
  },
  {
    id: '7',
    name: 'Chicken Noodles',
    description: 'Stir-fried noodles with chicken and fresh vegetables',
    price: 189.99,
    image: 'https://images.pexels.com/photos/1907244/pexels-photo-1907244.jpeg?auto=compress&cs=tinysrgb&w=400',
    restaurant: 'Minarva Grand',
    category: 'noodles',
    rating: 4.3,
    isPopular: true,
    preparationTime: '15-20 mins'
  },
  {
    id: '8',
    name: 'Margherita Pizza',
    description: 'Classic Italian pizza with fresh mozzarella and basil',
    price: 249.99,
    image: 'https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg?auto=compress&cs=tinysrgb&w=400',
    restaurant: 'Paradise Grand',
    category: 'pizza',
    rating: 4.6,
    isPopular: true,
    preparationTime: '18-22 mins'
  }
];

export const categories = [
  { id: 'breakfast', name: 'Breakfast', emoji: '🍳', description: 'Start your day right' },
  { id: 'biryani', name: 'Biryani', emoji: '🍛', description: 'Aromatic rice dishes' },
  { id: 'pizza', name: 'Pizza', emoji: '🍕', description: 'Italian favorites' },
  { id: 'noodles', name: 'Noodles', emoji: '🍜', description: 'Asian delights' },
  { id: 'burger', name: 'Burger', emoji: '🍔', description: 'Juicy burgers' },
  { id: 'beverages', name: 'Beverages', emoji: '🥤', description: 'Refreshing drinks' }
];

export const restaurants = [
  {
    id: '1',
    name: 'Andhra Spice',
    location: 'Madhapur, Hyderabad',
    image: 'https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.5,
    deliveryTime: '25-30 mins'
  },
  {
    id: '2',
    name: 'Mc donalds',
    location: 'Manikonda, Hyderabad',
    image: 'https://images.pexels.com/photos/1552635/pexels-photo-1552635.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.2,
    deliveryTime: '15-20 mins'
  },
  {
    id: '3',
    name: 'Paradise Grand',
    location: 'Banjara Hills, Hyderabad',
    image: 'https://images.pexels.com/photos/67468/pexels-photo-67468.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    deliveryTime: '20-25 mins'
  },
  {
    id: '4',
    name: 'Minarva Grand',
    location: 'Kukatpally, Hyderabad',
    image: 'https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.4,
    deliveryTime: '18-25 mins'
  }
];