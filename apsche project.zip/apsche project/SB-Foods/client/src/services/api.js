import axios from 'axios';
const API = axios.create({ baseURL: 'http://localhost:5000/api' });

export const register = (data) => API.post('/users/register', data);
export const login = (data) => API.post('/users/login', data);
export const fetchProducts = () => API.get('/products');
export const getCart = () => API.get('/cart');
export const addToCart = (item) => API.post('/cart', item);
export const removeFromCart = (id) => API.delete(`/cart/${id}`);
export const placeOrder = (order) => API.post('/orders', order);
export const getUserOrders = () => API.get('/orders/my');
export const fetchAllUsers = () => API.get('/admin/users');
export const fetchAllOrders = () => API.get('/admin/orders');
export const fetchAllProducts = () => API.get('/admin/products');
export const fetchMyRestaurant = () => API.get('/restaurants/me');
export const updateRestaurantMenu = (menu) => API.put('/restaurants/menu', menu);