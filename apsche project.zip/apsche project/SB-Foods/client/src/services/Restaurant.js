export const fetchMyRestaurant = (id) => API.get(`/restaurants/${id}`);
export const updateRestaurantMenu = (id, data) => API.put(`/restaurants/${id}/menu`, data);