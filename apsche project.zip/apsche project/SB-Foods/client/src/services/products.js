export const fetchProducts = () => API.get('/products');
