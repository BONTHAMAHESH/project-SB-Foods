export const getCart = (userId) => API.get(`/cart/${userId}`);
export const addToCart = (userId, product) => API.post(`/cart/${userId}`, product);
export const removeFromCart = (userId, productId) => API.delete(`/cart/${userId}/${productId}`);
