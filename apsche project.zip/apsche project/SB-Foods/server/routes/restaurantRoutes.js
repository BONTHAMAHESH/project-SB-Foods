const express = require('express');
const router = express.Router();

// Define restaurant routes here
// Example: router.get('/', (req, res) => { res.send('Restaurant list'); });

module.exports = router;