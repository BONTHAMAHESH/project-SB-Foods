const express = require('express');
const router = express.Router();

// Define admin routes here
// Example: router.get('/', (req, res) => { res.send('Admin list'); });

module.exports = router;
