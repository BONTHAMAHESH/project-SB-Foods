const express = require('express');
const router = express.Router();

// Define order routes here
// Example: router.get('/', (req, res) => { res.send('Order list'); });

module.exports = router;